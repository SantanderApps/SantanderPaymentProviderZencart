<?php

/**
 * @file includes.php
 * @author Consid S5 AB <henrik.soderlind@consid.se>
 * @version 1.0.0
 * @created 2015-aug-10
 */

require_once DIR_FS_CATALOG . 'extras/santander/src/autoloader.php';
require_once __DIR__ . '/classes/Santander_APIConnector.php';