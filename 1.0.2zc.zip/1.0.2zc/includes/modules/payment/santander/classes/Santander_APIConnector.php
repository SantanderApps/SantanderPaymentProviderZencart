<?php

/**
 * Santander_APIConnector
 *
 * @file Santander_APIConnector.php
 * @author Consid S5 AB <henrik.soderlind@consid.se>
 * @version 1.0.0
 * @created 2015-aug-10
 */

use Santander\base\Config;

class Santander_APIConnector implements Santander\base\APIConnectorInterface {
    public function getData($configKey) {
        switch ($configKey) {
            case Config::CONFIG_KEY_TEST_MODE:
                return $this->_getMode() == santander_loan::STATUS_TEST;
                break;
            case Config::CONFIG_KEY_SANDBOX_MODE:
                return $this->_getMode() == santander_loan::STATUS_TEST;
                break;
            case Config::CONFIG_KEY_STORE_ID:
                return $this->_getStoreId();
                break;
            case Config::CONFIG_KEY_USERNAME:
                return $this->_getUsername();
                break;
            case Config::CONFIG_KEY_PASSWORD:
                return $this->_getPassword();
                break;
            case Config::CONFIG_KEY_CERTIFICATE:
                return $this->_getCertificate();
                break;
            case Config::CONFIG_KEY_MERCHANT_ID:
                return $this->_getMerchantId();
                break;
            case Config::CONFIG_KEY_LANGUAGE:
                return $this->_getLanguage();
                break;
            case Config::CONFIG_KEY_SITE_EMAIL_ADDRESS:
                return $this->_getSiteMail();
                break;
            case Config::CONFIG_KEY_SITE_NAME:
                return $this->_getSiteName();
                break;
            case Config::CONFIG_KEY_PLATFORM_NAME:
                return $this->_getPlatformName();
                break;
            case Config::CONFIG_KEY_PLATFORM_VERSION:
                return $this->_getPlatformVersion();
                break;
            case Config::CONFIG_KEY_MODULE_VERSION:
                return $this->_getModuleVersion();
                break;
            case Config::CONFIG_KEY_MODULE_INSTALLATION_DATE:
                return $this->_getModuleInstallationDate();
                break;
            case Config::CONFIG_KEY_ENABLE_EXTENDED_LOGGING:
                return $this->_enableExtendedLogging();
                break;
            case Config::CONFIG_KEY_RETURN_URL:
                return $this->_getReturnUrl();
                break;
            case Config::CONFIG_KEY_ACCESS_LOG_EXTERNAL:
                return $this->_getAccessLogExternal();
                break;
        }
    }
    
    private function _getMode() {
        return MODULE_PAYMENT_SANTANDER_LOAN_MODE;
    }
    
    private function _getStoreId() {
        return MODULE_PAYMENT_SANTANDER_LOAN_STORE_ID;
    }
    
    private function _getUsername() {
        return MODULE_PAYMENT_SANTANDER_LOAN_USERNAME;
    }
    
    private function _getPassword() {
        return MODULE_PAYMENT_SANTANDER_LOAN_PASSWORD;
    }
    
    private function _getCertificate() {
        return file_get_contents(dirname(__DIR__) . '/' . MODULE_PAYMENT_SANTANDER_LOAN_CERTIFICATE_NAME);
    }
    
    private function _getMerchantId() {
        return MODULE_PAYMENT_SANTANDER_LOAN_MERCHANT_ID;
    }
    
    private function _getLanguage() {
        global $language;
        return $language;
    }
    
    private function _getSiteMail() {
        return STORE_OWNER_EMAIL_ADDRESS;
    }
    
    private function _getSiteName() {
        return STORE_NAME;
    }
    
    private function _getPlatformName() {
        return 'Zen Cart';
    }
    
    private function _getPlatformVersion() {
        return PROJECT_VERSION_MAJOR . '.' . PROJECT_VERSION_MINOR . (PROJECT_VERSION_PATCH1 != '' ? 'p' . PROJECT_VERSION_PATCH1 : '');
    }
    
    private function _getModuleVersion() {
        return '1.0.2zc';
    }
    
    private function _getModuleInstallationDate() {
        return MODULE_PAYMENT_SANTANDER_INSTALLATION_DATE;
    }
    
    private function _enableExtendedLogging() {
        return TRUE;
    }
    
    private function _getReturnUrl() {
        return zen_href_link(FILENAME_CHECKOUT_PROCESS);
    }
    
    private function _getAccessLogExternal() {
        return MODULE_PAYMENT_SANTANDER_LOAN_ACCESS_LOGS == 'True';
    }
}
