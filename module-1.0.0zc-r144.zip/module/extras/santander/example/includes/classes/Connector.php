<?php

/**
 * Connector
 *
 * @file Connector.php
 * @author Consid S5 AB <henrik.soderlind@consid.se>
 * @version 1.0.0
 * @created 2015-aug-06
 */

use Santander\base\Config;

class Connector implements Santander\base\APIConnectorInterface {
    public function getData($configKey) {
        switch ($configKey) {
            case Config::CONFIG_KEY_TEST_MODE:
                return $this->_getMode() == 'test';
                break;
            case Config::CONFIG_KEY_SANDBOX_MODE:
                return $this->_getMode() == 'sandbox';
                break;
            case Config::CONFIG_KEY_STORE_ID:
                return $this->_getStoreId();
                break;
            case Config::CONFIG_KEY_USERNAME:
                return $this->_getUsername();
                break;
            case Config::CONFIG_KEY_PASSWORD:
                return $this->_getPassword();
                break;
            case Config::CONFIG_KEY_CERTIFICATE:
                return $this->_getCertificate();
                break;
            case Config::CONFIG_KEY_MERCHANT_ID:
                return $this->_getMerchantId();
                break;
            case Config::CONFIG_KEY_LANGUAGE:
                return $this->_getLanguage();
                break;
            case Config::CONFIG_KEY_SITE_EMAIL_ADDRESS:
                return $this->_getSiteMail();
                break;
            case Config::CONFIG_KEY_SITE_NAME:
                return $this->_getSiteName();
                break;
            case Config::CONFIG_KEY_PLATFORM_NAME:
                return $this->_getPlatformName();
                break;
            case Config::CONFIG_KEY_PLATFORM_VERSION:
                return $this->_getPlatformVersion();
                break;
            case Config::CONFIG_KEY_MODULE_VERSION:
                return $this->_getModuleVersion();
                break;
            case Config::CONFIG_KEY_MODULE_INSTALLATION_DATE:
                return $this->_getModuleInstallationDate();
                break;
            case Config::CONFIG_KEY_ENABLE_EXTENDED_LOGGING:
                return $this->_enableExtendedLoggin();
                break;
        }
    }
    
    private function _getMode() {
        return 'sandbox';
    }
    
    private function _getStoreId() {
        return 'EasyStubTesters';
    }
    
    private function _getUsername() {
        return 'testbutik1';
    }
    
    private function _getPassword() {
        return 'testbutik1';
    }
    
    private function _getCertificate() {
        return file_get_contents(WEB_ROOT . DIRECTORY_SEPARATOR . 'mycert.pem');
    }
    
    private function _getMerchantId() {
        if ($this->_getMode() == 'test' || $this->_getMode() == 'prod') {
            return 90195844;
        }
        else { // Sandbox
            return '';
        }
    }
    
    private function _getLanguage() {
        return 'sv-SE';
    }
    
    private function _getSiteMail() {
        return 'henrik.soderlind@consid.se';
    }
    
    private function _getSiteName() {
        return 'Santander LOw Level API';
    }
    
    private function _getPlatformName() {
        return 'Test PLatform';
    }
    
    private function _getPlatformVersion() {
        return '1.0';
    }
    
    private function _getModuleVersion() {
        return '1.0.0tp';
    }
    
    private function _getModuleInstallationDate() {
        return date('Y-m-d H:i');
    }
    
    private function _enableExtendedLoggin() {
        return TRUE;
    }
}
